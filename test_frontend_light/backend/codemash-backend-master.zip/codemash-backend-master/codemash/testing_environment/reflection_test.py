### WARNING, THIS WHOLE PROGRAM ASSUMES THERE ARE NO SYNTAX ERRORS
### AND THAT THE FILE IS PEP8 COMPLIANT
import sys

# this is the name of a function or method without a name


class EmptyName(str):
    def __str__(self):
        return "main"

    def __int__(self):
        return 0
NO_NAME = EmptyName()


def get_name(line: str):
    # loop until the name of the thing
    line = line.lstrip(" ")
    c = 0
    while line[c] != " ":
        c += 1
    c += 1
    name = ""

    # get the thing
    while line[c].isalnum():
        name += line[c]
        c += 1
    return name


def create_class_dict(filename: str):
    file = [""]
    with open(filename) as the_thing:
        file = the_thing.readlines();
    file = [line.rstrip() for line in file]

    # Get the methods
    classes = dict()
    classes[NO_NAME] = {NO_NAME: []} # methods[class][method].append(line) to add a newline

    curr_class = NO_NAME   # keeps track of current class
    curr_method = NO_NAME  # current method

    for line in file:
        if len(line) > 6 and line[0:5] == "class": # is a class
            curr_class = get_name(line)
            curr_method = NO_NAME
            classes[curr_class] = {NO_NAME: []}

        elif len(line.lstrip(" ")) > 4 and line.lstrip(" ")[0:3] == "def":  # is a method or function
            if line[0] != " ":  # if it is a top level function
                curr_class = NO_NAME
            curr_method = get_name(line)
            classes[curr_class][curr_method] = []

        else:
            if not line or (not line[0].isspace() and line[0] != "#"):  # if the class or method has ended
                curr_method = NO_NAME
                curr_class = NO_NAME
            classes[curr_class][curr_method].append(line)

    return classes


def print_classes(classes: dict):
    for class_name in classes:
        print(str(class_name) + ": ")
        for method in classes[class_name]:
            if classes[class_name][method]:
                print("\t" + str(method) + ": ")
                [print(classes[class_name][method][i]) for i in range(len(classes[class_name][method]))]


print_classes(create_class_dict("reflection_test.py"))
